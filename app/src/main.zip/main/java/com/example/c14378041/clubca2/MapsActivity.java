package com.example.c14378041.clubca2;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng syngerGAA = new LatLng(53.3030601, -6.2943575);
        LatLng clontarfGAA = new LatLng(53.3697547, -6.1844166);
        LatLng vincentsGAA = new LatLng(53.374042,-6.2300634);
        LatLng crokesGAA = new LatLng(53.2816864,-6.2212722);
        LatLng ballymunGAA = new LatLng(53.4175189,-6.2664879);
        mMap.addMarker(new MarkerOptions().position(clontarfGAA).title("Clontarf GFC").snippet("St.Annes Park, Clontarf"));
        mMap.addMarker(new MarkerOptions().position(syngerGAA).title("Templeogue Synge Street GFC").snippet("Bushy Park, Templeogue Road, Terenure"));
        mMap.addMarker(new MarkerOptions().position(vincentsGAA).title("St Vincents GFC").snippet("Malahide Road, Dublin"));
        mMap.addMarker(new MarkerOptions().position(crokesGAA).title("Kilmacud Crokes GFC").snippet("82 Knocknashee, Goatstown"));
        mMap.addMarker(new MarkerOptions().position(ballymunGAA).title("Ballymun Kickhams GFC").snippet("Collinstown Lane, Ballymun"));

        LatLng dublin = new LatLng(53.3242381,-6.385785);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(dublin, 10));
    }

    public void ButtonClick(View v) {
        Button button = (Button) v;

        Intent intent1 = new Intent(this, MainActivity.class);
        startActivity(intent1);

    }}

